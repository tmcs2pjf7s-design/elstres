ELS TR3S — BANNER SORTEO

Contenido:
- index.html
- assets/sorteo-instagram.png

Despliegue:
1. Sube index.html y la carpeta assets a tu hosting.
2. Mantén la ruta assets/sorteo-instagram.png.
3. Abre index.html o configura la carpeta como raíz de la página.

Enlaces configurados:
- Condiciones: https://rushsystems.es/Sorteoelstr3s
- Instagram: https://www.instagram.com/frankfurt_els_tr3s/
- Instagram: https://www.instagram.com/elstr3scanroca/

El diseño es responsive y los tres botones funcionan en móvil y escritorio.
